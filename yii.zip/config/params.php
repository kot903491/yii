<?php

return [
    'adminEmail' => 'kot903491@gmail.com',
];
