<?php
/* @var $model app\models\MyModel */
?>
<?= \yii\widgets\DetailView::widget(['model'=>$model]);?>
